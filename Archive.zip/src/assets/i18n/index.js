export { default as I18NProvider } from './provider'
export { LOCALES } from './locales'
