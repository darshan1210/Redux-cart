import axios from 'axios'

const Mainapi = axios.create({
  baseURL: 'https://6364c85f7b209ece0f4dd0e8.mockapi.io/'
})

export default Mainapi
