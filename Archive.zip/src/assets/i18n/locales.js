export const LOCALES = {
  ENGLISH: 'en',
  HINDI: 'hi',
  GUJARATI: 'guj'
}
