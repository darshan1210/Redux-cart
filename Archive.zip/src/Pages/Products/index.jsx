/* eslint-disable no-unused-vars */
/* eslint-disable react/prop-types */
import React, { useEffect, useState } from 'react'
import './Products.scss'
import PopUp from '../../Shared/Componet/popup-box'
import { useNavigate } from 'react-router-dom'
import { useSelector } from 'react-redux'
import { I18NProvider, LOCALES } from '../../assets/i18n'
import translate from '../../assets/i18n/translate'

function Product ({ btndata, allitem }) {
  const [categories, SetCategories] = useState([])
  const [products, SetProducts] = useState([])
  const [secondParent, setSecondparant] = useState([])
  const [secondBtnData, setSecondBtnData] = useState([])
  const [pupupflag, setPopupflag] = useState(false)
  const [firstbtnactive, setFirstbtnactive] = useState(2)
  const [secondbtnactive, setSecondbtnactive] = useState(4)
  const [pupUpData, setPopUpData] = useState({})
  const [defultItems, setdefultItems] = useState({})

  const totalBill = useSelector(state => state.TotalBill.data)

  const [totalPrice, setTotalPrice] = useState((totalBill) || 0)
  const [totalItem, setTotalItem] = useState(0)
  const [lang, setLang] = useState(LOCALES.ENGLISH)

  const cartItems = useSelector(state => state.cartItems.data)
  const naviagte = useNavigate()

  useEffect(() => {
    (cartItems)
      ? setTotalItem(cartItems.map((item) => item.totalCount).reduce((acc, curr) => acc + curr, 0))
      : setTotalItem(0);
    (totalBill)
      ? setTotalPrice(totalBill)
      : setTotalPrice(0)
  }, [totalBill])

  useEffect(() => {
    SetCategories(btndata)
    SetProducts(allitem)
  }, [])

  function Firstclick (id, name) {
    setFirstbtnactive(id)
    const newtemp1 = categories.filter((element) => element.parent === id)
    setSecondparant(newtemp1)
    setdefultItems(newtemp1[0])
  }
  function Secondclick (id) {
    setSecondbtnactive(id)
    const newtemp2 = products.filter((element) => element.parentId === id)
    setSecondBtnData(newtemp2)
  }
  useEffect(() => {
    Firstclick(2)
    Secondclick(4)
  }, [categories, products])

  useEffect(() => {
    if (defultItems) {
      const newnew = defultItems.id
      Secondclick(newnew)
    }
  }, [secondParent])

  function popupdata (data) {
    setPopUpData(data)
    setPopupflag(!pupupflag)
  }

  return (
    <I18NProvider locale={lang}>
    <div className='main_container'>
      <div className="app">
        <div className="header">
          <span className='heading'>{translate('restaurantName')}</span>
          <span className='Street_address'>{translate('restaurantAddress', { break: <br/> })}</span>
        </div>

        <div className="food_type">
          {categories.map((element, index) => {
            const { id, name } = element
            return ((element.parent == null) && <button key={index} onClick={() => Firstclick(id, name)} className={firstbtnactive === id ? 'MainActive' : 'food_type_btn'} >{name}</button>)
          })}
        </div>
        <div className="stater_type">
          {
            secondParent.map((element, index) => {
              const { id, name } = element
              return (<button key={index} className={secondbtnactive === id ? 'MainActiveBtn2' : 'stater_type_btn'} onClick={() => Secondclick(id)}>{name} </button>)
            })
          }
        </div>
        <div>{(secondBtnData.length !== 0)
          ? (secondBtnData.map((element, index) => {
              const { name, description, price } = element
              return (
                <div className="product_info" key={index} onClick={() => popupdata(element)}>
                  <div className="product_info_left">
                    <span className="product_title">{name}</span>
                    <span className="product_Discription">{description}</span>
                  </div>
                  <div className="product_info_right">
                    <span className="product_prize">£ {price}</span>
                  </div>
                </div>
              )
            }))
          : (<h4 className="product_info" >This item is not Available</h4>)
          }

        </div>

        <button onClick={() => setLang(LOCALES.ENGLISH)}>English</button>
        <button onClick={() => setLang(LOCALES.HINDI)}>Hindi</button>
        <button onClick={() => setLang(LOCALES.GUJARATI)}>Gujarati</button>

        <div className="view_basket" onClick={() => { naviagte('/checkout') }}>
          <div className="view_basket_title">{translate('viewBasket')}</div>
          <span className="count_basket_view">
          £ {totalPrice.toFixed(2)} / {totalItem} {translate('items')}
          </span>
        </div>

        {(pupupflag) && <PopUp flag={popupdata} data={pupUpData} checkParent={categories}/>}

      </div>
    </div>
    </I18NProvider>
  )
}
export default Product
