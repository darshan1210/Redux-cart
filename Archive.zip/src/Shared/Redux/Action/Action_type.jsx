export const ADD_TO_CART = 'ADD_TO_CART'
export const CLEAR_CART = 'CLEAR-CART'
export const TOTAL_BILL = 'TOTAL_BILL'
export const CLEAR_BILL = 'CLEAR_BILL'
