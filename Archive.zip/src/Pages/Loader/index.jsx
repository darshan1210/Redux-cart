import React from 'react'
import glass from '../../assets/img/SPLASH_SCREEN-1.png'
import './loader.scss'
function Load () {
  return (
    <div className='main_container'>
    <div className="app">
            <div className="mid">
                <img src={glass} alt="" />
            </div>
        </div>
        </div>
  )
}

export default Load
