import React from 'react'
import 'language.scss'

function Language () {
  return (
        <>
            <div className="language_background">

            </div>
        </>
  )
}
export default Language
